package com.caltrack.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.caltrack.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDb.build(app)

    val selectedDay = MutableStateFlow(LocalDate.now().toEpochDay())
    val query = MutableStateFlow("")

    val profile: StateFlow<Profile> = db.profileDao().observe().map { it ?: Profile() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, Profile())

    val dayLogs: StateFlow<List<LogEntry>> = selectedDay.flatMapLatest { db.logDao().forDay(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Last 30 days of logs (drives Home + Analytics). */
    val recent: StateFlow<List<LogEntry>> = run {
        val today = LocalDate.now().toEpochDay()
        db.logDao().range(today - 29, today)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val weights: StateFlow<List<WeightEntry>> = db.weightDao().all()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val results: StateFlow<List<Food>> = query.flatMapLatest { db.foodDao().search(it.trim()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch(Dispatchers.IO) {
            if (db.foodDao().count() == 0) db.foodDao().insertAll(Seed.foods())
        }
    }

    fun addLog(day: Long, meal: String, food: Food, grams: Double, label: String) {
        val n = food.nutrition(grams)
        viewModelScope.launch(Dispatchers.IO) {
            db.logDao().insert(
                LogEntry(day = day, meal = meal, name = food.name, quantityLabel = label, grams = grams,
                    calories = n.cal, protein = n.p, carbs = n.c, fat = n.f, fiber = n.fib)
            )
        }
    }

    fun deleteLog(e: LogEntry) { viewModelScope.launch(Dispatchers.IO) { db.logDao().delete(e) } }

    fun addCustomFood(food: Food, onSaved: (Food) -> Unit) {
        viewModelScope.launch {
            val id = withContext(Dispatchers.IO) { db.foodDao().insert(food) }
            onSaved(food.copy(id = id))
        }
    }

    fun saveProfile(p: Profile, weightKg: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            db.profileDao().upsert(p)
            db.weightDao().upsert(WeightEntry(LocalDate.now().toEpochDay(), weightKg))
        }
    }

    fun logWeight(kg: Double) {
        viewModelScope.launch(Dispatchers.IO) { db.weightDao().upsert(WeightEntry(LocalDate.now().toEpochDay(), kg)) }
    }

    fun setTheme(mode: Int) {
        viewModelScope.launch(Dispatchers.IO) { db.profileDao().upsert(profile.value.copy(darkMode = mode)) }
    }
}

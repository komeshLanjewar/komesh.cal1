package com.caltrack.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.caltrack.app.ui.*
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { CalTrackApp() }
    }
}

@Composable
fun CalTrackApp(vm: MainViewModel = viewModel()) {
    val profile by vm.profile.collectAsStateWithLifecycle()
    val dark = when (profile.darkMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    CalTrackTheme(dark) {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        var sheet by remember { mutableStateOf<Pair<String, Long>?>(null) }
        val items = listOf(
            "Home" to Icons.Filled.Home, "Food Diary" to Icons.Filled.Restaurant,
            "Analytics" to Icons.Filled.BarChart, "Profile" to Icons.Filled.Person
        )
        Scaffold(bottomBar = {
            NavigationBar {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, label) }, label = { Text(label) })
                }
            }
        }) { pad ->
            Box(Modifier.padding(pad)) {
                Crossfade(tab, label = "tab") { t ->
                    when (t) {
                        0 -> HomeScreen(vm) { meal -> sheet = meal to LocalDate.now().toEpochDay() }
                        1 -> DiaryScreen(vm) { meal, day -> sheet = meal to day }
                        2 -> AnalyticsScreen(vm) { day -> vm.selectedDay.value = day; tab = 1 }
                        else -> ProfileScreen(vm)
                    }
                }
            }
        }
        sheet?.let { (meal, day) -> AddFoodSheet(vm, meal, day) { sheet = null } }
    }
}

package com.caltrack.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.caltrack.app.MainViewModel
import com.caltrack.app.data.*
import java.time.LocalDate

@Composable
private fun MiniStat(label: String, value: String, unit: String, modifier: Modifier) {
    AppCard(modifier) {
        Muted(label)
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Muted(unit)
    }
}

@Composable
fun AnalyticsScreen(vm: MainViewModel, onOpenDay: (Long) -> Unit) {
    val profile by vm.profile.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val weights by vm.weights.collectAsStateWithLifecycle()
    var period by rememberSaveable { mutableIntStateOf(0) }
    var wIn by rememberSaveable { mutableStateOf("") }
    var wErr by remember { mutableStateOf<String?>(null) }

    val today = LocalDate.now().toEpochDay()
    val n = if (period == 0) 7 else 30
    val from = today - (n - 1)
    val target = profile.calorieTarget
    val series = dailySums(recent, from, today)
    val logged = series.count { it > 0f }
    val avg = if (logged > 0) series.sum() / logged else 0f
    val onTarget = series.count { it > 0f && it <= target * 1.05f }
    val periodLogs = recent.filter { it.day >= from }
    val mt = periodLogs.totals()
    val d = maxOf(logged, 1)
    val diff = avg - target
    val byDay = recent.groupBy { it.day }
    val wlist = weights.takeLast(30)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Analytics", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold) }
        item {
            TabRow(selectedTabIndex = period, containerColor = Color.Transparent) {
                Tab(selected = period == 0, onClick = { period = 0 }, text = { Text("Week") })
                Tab(selected = period == 1, onClick = { period = 1 }, text = { Text("Month") })
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniStat("Average", fmt(avg), "kcal / day", Modifier.weight(1f))
                MiniStat("Days logged", "$logged", "of $n", Modifier.weight(1f))
                MiniStat("On target", "$onTarget", "days", Modifier.weight(1f))
            }
        }
        item {
            AppCard {
                SectionTitle(if (period == 0) "Weekly calories" else "Monthly calories")
                Spacer(Modifier.height(12.dp))
                if (period == 0) {
                    BarChart(series, (from..today).map { dayLabel(it) }, target.toFloat())
                } else {
                    LineChart(series, ref = target.toFloat())
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Muted(shortDate(from)); Muted(shortDate(today))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Muted("Dashed line = daily goal of $target kcal")
            }
        }
        item {
            AppCard {
                SectionTitle("Consumed vs target")
                Spacer(Modifier.height(10.dp))
                if (logged == 0) Muted("Log some meals to see your comparison.") else {
                    Text(
                        if (diff > 0) "${fmt(diff)} kcal over target per day" else "${fmt(-diff)} kcal under target per day",
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(10.dp))
                    Muted("Average intake: ${fmt(avg)} kcal")
                    LinearProgressIndicator(
                        progress = { (avg / target).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(10.dp),
                        color = if (diff > target * 0.05f) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    Muted("Target: $target kcal")
                    LinearProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxWidth().height(10.dp),
                        color = MaterialTheme.colorScheme.outline, trackColor = MaterialTheme.colorScheme.surfaceVariant)
                }
            }
        }
        item {
            AppCard {
                SectionTitle("Macros (daily average)")
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MacroDonut((mt.p / d).toFloat(), (mt.c / d).toFloat(), (mt.f / d).toFloat(), Modifier.size(110.dp))
                    Spacer(Modifier.width(20.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        LegendRow(ProteinColor, "Protein", "${fmt(mt.p / d)} g")
                        LegendRow(CarbColor, "Carbs", "${fmt(mt.c / d)} g")
                        LegendRow(FatColor, "Fat", "${fmt(mt.f / d)} g")
                        LegendRow(FiberColor, "Fiber", "${fmtQ(mt.fib / d)} g")
                    }
                }
            }
        }
        item {
            AppCard {
                SectionTitle("Weight tracking")
                Spacer(Modifier.height(10.dp))
                if (wlist.size >= 2) {
                    LineChart(wlist.map { it.kg.toFloat() }, color = MaterialTheme.colorScheme.tertiary)
                    Spacer(Modifier.height(4.dp))
                    Muted("${shortDate(wlist.first().day)} → ${shortDate(wlist.last().day)}")
                } else Muted("Log at least two weigh-ins (on different days) to see your trend.")
                if (wlist.isNotEmpty()) Text("Latest: ${fmtQ(wlist.last().kg)} kg", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.Top) {
                    NumField("Today's weight (kg)", wIn, { wIn = it; wErr = null }, Modifier.weight(1f), error = wErr)
                    Spacer(Modifier.width(10.dp))
                    Button(onClick = {
                        val v = wIn.toDoubleOrNull()
                        if (v == null || v !in 25.0..300.0) wErr = "25–300 kg" else { vm.logWeight(v); wIn = "" }
                    }, Modifier.padding(top = 8.dp)) { Text("Log") }
                }
            }
        }
        item { SectionTitle("History") }
        val days = (today downTo from).filter { byDay.containsKey(it) }
        if (days.isEmpty()) item { Muted("No food logged in this period yet.") }
        else items(days.size) { i ->
            val day = days[i]
            val t = byDay.getValue(day).totals()
            AppCard(Modifier.clickable { onOpenDay(day) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(dateLabel(day), fontWeight = FontWeight.SemiBold)
                        Muted("P ${fmt(t.p)} g · C ${fmt(t.c)} g · F ${fmt(t.f)} g")
                    }
                    Text("${fmt(t.cal)} kcal", fontWeight = FontWeight.Bold,
                        color = if (t.cal > target * 1.05) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(vm: MainViewModel) {
    val profile by vm.profile.collectAsStateWithLifecycle()
    val key = profile.copy(darkMode = 0)
    var age by remember(key) { mutableStateOf(profile.age.toString()) }
    var gender by remember(key) { mutableStateOf(profile.gender) }
    var height by remember(key) { mutableStateOf(fmtQ(profile.heightCm)) }
    var weight by remember(key) { mutableStateOf(fmtQ(profile.weightKg)) }
    var activity by remember(key) { mutableStateOf(profile.activity) }
    var goal by remember(key) { mutableStateOf(profile.goal) }
    var target by remember(key) { mutableStateOf(profile.calorieTarget.toString()) }
    var saved by remember { mutableStateOf(false) }

    val ageV = age.toIntOrNull(); val hV = height.toDoubleOrNull(); val wV = weight.toDoubleOrNull(); val tV = target.toIntOrNull()
    val ageErr = if (ageV == null || ageV !in 10..100) "Enter an age from 10 to 100" else null
    val hErr = if (hV == null || hV !in 100.0..250.0) "100–250 cm" else null
    val wErr = if (wV == null || wV !in 25.0..300.0) "25–300 kg" else null
    val tErr = if (tV == null || tV !in 800..6000) "Enter 800–6000 kcal" else null
    val estimate = if (ageErr == null && hErr == null && wErr == null)
        estimateTarget(ageV!!, gender, hV!!, wV!!, activity, goal) else null
    val themes = listOf("System", "Light", "Dark")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Profile", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
        AppCard {
            SectionTitle("About you")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NumField("Age", age, { age = it; saved = false }, Modifier.weight(1f), ageErr, integer = true)
                NumField("Height (cm)", height, { height = it; saved = false }, Modifier.weight(1f), hErr)
            }
            NumField("Weight (kg)", weight, { weight = it; saved = false }, Modifier.fillMaxWidth(), wErr)
            Muted("Gender"); Spacer(Modifier.height(4.dp))
            ChipGroup(GENDERS, gender) { gender = it; saved = false }
            Spacer(Modifier.height(12.dp))
            Muted("Activity level"); Spacer(Modifier.height(4.dp))
            ChipGroup(ACTIVITIES.keys.toList(), activity) { activity = it; saved = false }
            Spacer(Modifier.height(12.dp))
            Muted("Fitness goal"); Spacer(Modifier.height(4.dp))
            ChipGroup(GOALS, goal) { goal = it; saved = false }
        }
        AppCard {
            SectionTitle("Daily calorie target")
            Spacer(Modifier.height(8.dp))
            if (estimate != null) {
                Text("Estimated for your profile: $estimate kcal", fontWeight = FontWeight.SemiBold)
                Muted("Mifflin-St Jeor formula × activity level, adjusted for your goal.")
                TextButton(onClick = { target = estimate.toString(); saved = false }) { Text("Use estimate") }
            } else Muted("Fill in the fields above to get an estimate.")
            NumField("Target (kcal) – customize freely", target, { target = it; saved = false }, Modifier.fillMaxWidth(), tErr, integer = true)
        }
        Button(
            onClick = {
                if (ageErr == null && hErr == null && wErr == null && tErr == null) {
                    vm.saveProfile(Profile(age = ageV!!, gender = gender, heightCm = hV!!, weightKg = wV!!, activity = activity,
                        goal = goal, calorieTarget = tV!!, darkMode = profile.darkMode), wV)
                    saved = true
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Save profile") }
        if (saved) Text("Saved ✓", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        AppCard {
            SectionTitle("Appearance")
            Spacer(Modifier.height(8.dp))
            ChipGroup(themes, themes[profile.darkMode.coerceIn(0, 2)]) { vm.setTheme(themes.indexOf(it)) }
        }
        Spacer(Modifier.height(8.dp))
    }
}

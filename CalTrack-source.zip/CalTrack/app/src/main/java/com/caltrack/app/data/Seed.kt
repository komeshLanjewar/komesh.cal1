package com.caltrack.app.data

/** Built-in food database. Format: name|kcal|protein|carbs|fat|fiber|serving unit|serving grams  (nutrition per 100 g) */
object Seed {
    private const val DATA = """
Roti / Chapati|300|9.6|55|3.7|4|piece|40
Phulka|264|9|52|1|4|piece|30
Paratha (plain)|326|7.5|46|12.5|3.5|piece|80
Aloo Paratha|250|5.5|33|10.5|2.5|piece|100
Naan|290|9|50|5.5|2|piece|90
Puri|400|7.5|47|20|2.5|piece|30
Thepla|290|8|40|11|5|piece|40
White Rice (cooked)|130|2.7|28|0.3|0.4|bowl|150
Brown Rice (cooked)|123|2.7|25.6|1|1.8|bowl|150
Jeera Rice|150|3|27|3.5|0.8|bowl|150
Veg Biryani|150|3.5|24|4.5|1.5|bowl|250
Chicken Biryani|165|8|20|5.5|0.8|bowl|250
Khichdi|110|4|18|2|1.5|bowl|200
Poha|130|2.5|24|3|1.2|bowl|150
Upma|150|3.5|22|5.5|1.5|bowl|150
Idli|138|4|28|0.4|1|piece|40
Plain Dosa|168|3.9|29|3.7|1.2|piece|100
Masala Dosa|190|4|28|7|2|piece|150
Uttapam|165|5|25|5|1.5|piece|100
Dhokla|160|6|25|4|2|piece|40
Besan Chilla|180|8|22|6|4|piece|70
Sambar|60|3|9|1.5|2|bowl|200
Coconut Chutney|180|2|6|17|3|g|100
Dal Tadka|120|6.5|14|4.5|3|bowl|200
Toor Dal (cooked)|105|6|14|3|3|bowl|200
Moong Dal (cooked)|100|7|15|1.5|3|bowl|200
Rajma Curry|120|6.5|17|3|5|bowl|200
Chole (Chickpea Curry)|150|7|20|5|6|bowl|200
Paneer|265|18|1.2|20.8|0|g|100
Paneer Bhurji|230|13|5|17|1|bowl|150
Palak Paneer|150|7|5|11|2|bowl|200
Paneer Butter Masala|200|8|8|16|1.5|bowl|200
Boiled Egg|155|13|1.1|11|0|piece|50
Egg Omelette|154|10.6|0.6|12|0|piece|60
Egg Bhurji|180|11|3|14|0.5|bowl|150
Chicken Breast (cooked)|165|31|0|3.6|0|g|100
Chicken Curry|150|14|4|8.5|1|bowl|200
Tandoori Chicken|150|20|3|6|0.5|piece|100
Butter Chicken|150|12|6|9|1|bowl|200
Fish Curry|120|14|3|6|0.5|bowl|200
Fried Fish|200|20|6|11|0.5|piece|100
Mutton Curry|190|16|4|12|0.5|bowl|200
Soya Chunks (dry)|345|52|33|0.5|13|g|100
Tofu|76|8|1.9|4.8|0.3|g|100
Aloo Sabzi|110|2|17|4|2|bowl|150
Mixed Veg Curry|75|2.5|8|4|2.5|bowl|150
Bhindi Fry|90|2|8|6|3|bowl|150
Gobi Sabzi|80|2.5|7|5|2.5|bowl|150
Pav Bhaji|160|4|22|6|3|bowl|200
Spinach (Palak)|23|2.9|3.6|0.4|2.2|g|100
Tomato|18|0.9|3.9|0.2|1.2|piece|100
Onion|40|1.1|9.3|0.1|1.7|piece|100
Cucumber|15|0.7|3.6|0.1|0.5|g|100
Carrot|41|0.9|9.6|0.2|2.8|piece|60
Broccoli|34|2.8|7|0.4|2.6|g|100
Boiled Potato|87|1.9|20|0.1|1.8|piece|150
Sweet Potato|86|1.6|20|0.1|3|piece|130
Green Salad|20|1|4|0.2|1.5|bowl|100
Banana|89|1.1|23|0.3|2.6|piece|120
Apple|52|0.3|14|0.2|2.4|piece|180
Mango|60|0.8|15|0.4|1.6|cup|165
Orange|47|0.9|12|0.1|2.4|piece|130
Papaya|43|0.5|11|0.3|1.7|bowl|150
Grapes|69|0.7|18|0.2|0.9|cup|150
Watermelon|30|0.6|7.6|0.2|0.4|cup|150
Pomegranate|83|1.7|19|1.2|4|bowl|150
Guava|68|2.6|14|1|5.4|piece|100
Avocado|160|2|9|15|7|piece|150
Milk (Whole)|62|3.2|4.8|3.3|0|cup|245
Milk (Toned)|58|3.1|4.7|3|0|cup|245
Curd / Dahi|60|3.1|4.7|3.3|0|bowl|150
Buttermilk (Chaas)|40|3.3|4.8|0.9|0|cup|240
Lassi (Sweet)|100|3|15|3|0|cup|240
Ghee|900|0|0|100|0|tsp|5
Butter|717|0.9|0.1|81|0|tsp|5
Cheese|350|22|2|28|0|slice|20
Almonds|579|21|22|50|12.5|handful|28
Peanuts|567|26|16|49|8.5|handful|28
Cashews|553|18|30|44|3.3|handful|28
Walnuts|654|15|14|65|6.7|handful|28
Peanut Butter|588|25|20|50|6|tbsp|16
Roasted Chana|364|19|61|6|17|handful|30
Makhana (Fox Nuts)|347|9.7|77|0.1|14.5|cup|30
Sprouts (Moong)|30|3|6|0.2|1.8|bowl|100
Oats (dry)|389|17|66|7|11|serving|40
Oats Porridge (cooked)|71|2.5|12|1.5|1.7|bowl|200
Cornflakes|357|7.5|84|0.4|3.3|serving|30
White Bread|265|9|49|3.2|2.7|slice|28
Brown Bread|247|13|41|3.4|7|slice|30
Marie Biscuit|440|7|74|12|2|piece|8
Samosa|262|4.5|28|15|2.5|piece|80
Pakora|290|7|28|17|4|piece|25
Gulab Jamun|320|5|50|11|0.5|piece|40
Jalebi|370|2|70|10|0.5|piece|30
Sugar|387|0|100|0|0|tsp|4
Honey|304|0.3|82|0|0.2|tsp|21
Dark Chocolate|546|5|61|31|7|piece|10
Ice Cream|207|3.5|24|11|0.7|bowl|100
Potato Chips|536|7|53|34|4|serving|30
Pizza|266|11|33|10|2.3|slice|107
Veg Burger|250|7|34|10|2|piece|150
Chicken Burger|260|14|29|10|1.5|piece|180
French Fries|312|3.4|41|15|3.8|serving|100
Pasta (cooked)|158|5.8|31|0.9|1.8|bowl|200
Instant Noodles (cooked)|138|3.2|20|5|1|bowl|200
Tea (Milk & Sugar)|45|1.2|7|1.5|0|cup|150
Coffee (Milk & Sugar)|50|1.5|7|1.8|0|cup|150
Black Coffee|2|0.3|0|0|0|cup|240
Cola|42|0|10.6|0|0|cup|240
Orange Juice|45|0.7|10|0.2|0.2|cup|240
Coconut Water|19|0.7|3.7|0.2|1.1|cup|240
Whey Protein|400|80|8|6|0|scoop|30
Sattu|413|22|65|7|18|tbsp|15
"""

    fun foods(): List<Food> = DATA.lines().filter { it.isNotBlank() }.map { line ->
        val p = line.split("|")
        Food(
            name = p[0].trim(), calories = p[1].toDouble(), protein = p[2].toDouble(),
            carbs = p[3].toDouble(), fat = p[4].toDouble(), fiber = p[5].toDouble(),
            unit = p[6].trim(), servingGrams = p[7].toDouble()
        )
    }
}

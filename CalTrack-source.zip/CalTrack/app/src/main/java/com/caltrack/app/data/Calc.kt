package com.caltrack.app.data

import java.util.Locale
import kotlin.math.roundToInt

val MEALS = listOf("Breakfast", "Lunch", "Dinner", "Snacks")
val ACTIVITIES = linkedMapOf("Sedentary" to 1.2, "Light" to 1.375, "Moderate" to 1.55, "Very Active" to 1.725)
val GOALS = listOf("Weight Loss", "Maintain Weight", "Weight Gain")
val GENDERS = listOf("Male", "Female", "Other")

data class Totals(val cal: Double = 0.0, val p: Double = 0.0, val c: Double = 0.0, val f: Double = 0.0, val fib: Double = 0.0)

fun List<LogEntry>.totals() = Totals(sumOf { it.calories }, sumOf { it.protein }, sumOf { it.carbs }, sumOf { it.fat }, sumOf { it.fiber })

fun Food.nutrition(grams: Double): Totals {
    val k = grams / 100.0
    return Totals(calories * k, protein * k, carbs * k, fat * k, fiber * k)
}

/** Mifflin-St Jeor BMR x activity factor, adjusted for goal. */
fun estimateTarget(age: Int, gender: String, heightCm: Double, weightKg: Double, activity: String, goal: String): Int {
    val offset = when (gender) { "Male" -> 5.0; "Female" -> -161.0; else -> -78.0 }
    val bmr = 10 * weightKg + 6.25 * heightCm - 5 * age + offset
    val tdee = bmr * (ACTIVITIES[activity] ?: 1.2)
    val adj = when (goal) { "Weight Loss" -> -500.0; "Weight Gain" -> 400.0; else -> 0.0 }
    return (((tdee + adj) / 10).roundToInt() * 10).coerceAtLeast(1200)
}

fun fmt(d: Double): String = d.roundToInt().toString()
fun fmt(d: Float): String = d.roundToInt().toString()
fun fmtQ(d: Double): String = if (d % 1.0 == 0.0) d.toInt().toString() else String.format(Locale.US, "%.1f", d)

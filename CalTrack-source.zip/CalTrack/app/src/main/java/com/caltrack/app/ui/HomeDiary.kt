package com.caltrack.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.caltrack.app.MainViewModel
import com.caltrack.app.data.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import kotlin.math.roundToInt

private val MEAL_EMOJI = mapOf("Breakfast" to "🌅", "Lunch" to "☀️", "Dinner" to "🌙", "Snacks" to "🍎")

@Composable
private fun StatLine(label: String, value: String) {
    Column {
        Muted(label)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MacroBar(label: String, value: Double, goal: Double, color: androidx.compose.ui.graphics.Color) {
    Column {
        Row {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
            Text("${fmt(value)} / ${fmt(goal)} g", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(3.dp))
        LinearProgressIndicator(
            progress = { if (goal > 0) (value / goal).toFloat().coerceIn(0f, 1f) else 0f },
            modifier = Modifier.fillMaxWidth().height(8.dp), color = color,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

@Composable
fun HomeScreen(vm: MainViewModel, onAdd: (String) -> Unit) {
    val profile by vm.profile.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val today = LocalDate.now().toEpochDay()
    val logs = recent.filter { it.day == today }
    val t = logs.totals()
    val target = profile.calorieTarget
    val remaining = target - t.cal
    val pct = if (target > 0) (t.cal / target * 100).roundToInt() else 0

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column {
                Text("CalTrack", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary)
                Muted(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM")))
            }
        }
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(contentAlignment = Alignment.Center) {
                        CalorieRing(t.cal.toFloat(), target.toFloat(), Modifier.size(150.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(fmt(abs(remaining)), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            Muted(if (remaining < 0) "kcal over" else "kcal left")
                        }
                    }
                    Spacer(Modifier.width(24.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatLine("Goal", "$target kcal")
                        StatLine("Consumed", "${fmt(t.cal)} kcal")
                        StatLine("Achieved", "$pct% of goal")
                    }
                }
            }
        }
        item {
            AppCard {
                SectionTitle("Macros today")
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MacroDonut(t.p.toFloat(), t.c.toFloat(), t.f.toFloat(), Modifier.size(96.dp))
                    Spacer(Modifier.width(18.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        MacroBar("Protein", t.p, target * 0.25 / 4, ProteinColor)
                        MacroBar("Carbs", t.c, target * 0.50 / 4, CarbColor)
                        MacroBar("Fat", t.f, target * 0.25 / 9, FatColor)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Muted("Fiber: ${fmtQ(t.fib)} g")
            }
        }
        item {
            AppCard {
                SectionTitle("Meals")
                MEALS.forEach { meal ->
                    val m = logs.filter { it.meal == meal }
                    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(MEAL_EMOJI[meal] ?: "", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(meal, fontWeight = FontWeight.SemiBold)
                            Muted("${m.size} item${if (m.size == 1) "" else "s"}")
                        }
                        Text("${fmt(m.sumOf { it.calories })} kcal", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.width(8.dp))
                        FilledTonalIconButton(onClick = { onAdd(meal) }) { Icon(Icons.Filled.Add, "Add food to $meal") }
                    }
                }
            }
        }
        item {
            AppCard {
                SectionTitle("This week vs target")
                Spacer(Modifier.height(10.dp))
                val from = today - 6
                BarChart(dailySums(recent, from, today), (from..today).map { dayLabel(it) }, target.toFloat())
                Spacer(Modifier.height(4.dp))
                Muted("Dashed line = your daily goal. Red bars went over.")
            }
        }
    }
}

@Composable
fun DiaryScreen(vm: MainViewModel, onAdd: (String, Long) -> Unit) {
    val day by vm.selectedDay.collectAsStateWithLifecycle()
    val logs by vm.dayLogs.collectAsStateWithLifecycle()
    val profile by vm.profile.collectAsStateWithLifecycle()
    val today = LocalDate.now().toEpochDay()
    val t = logs.totals()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                IconButton(onClick = { vm.selectedDay.value = day - 1 }) { Icon(Icons.Filled.KeyboardArrowLeft, "Previous day") }
                Text(dateLabel(day), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                IconButton(onClick = { vm.selectedDay.value = day + 1 }, enabled = day < today) {
                    Icon(Icons.Filled.KeyboardArrowRight, "Next day")
                }
            }
        }
        item {
            AppCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatLine("Calories", "${fmt(t.cal)} / ${profile.calorieTarget}")
                    StatLine("Protein", "${fmt(t.p)} g")
                    StatLine("Carbs", "${fmt(t.c)} g")
                    StatLine("Fat", "${fmt(t.f)} g")
                }
                Spacer(Modifier.height(8.dp))
                Muted("Fiber ${fmtQ(t.fib)} g")
            }
        }
        items(MEALS) { meal ->
            MealSection(meal, logs.filter { it.meal == meal }, onAdd = { onAdd(meal, day) }, onDelete = vm::deleteLog)
        }
    }
}

@Composable
private fun MealSection(meal: String, entries: List<LogEntry>, onAdd: () -> Unit, onDelete: (LogEntry) -> Unit) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(meal, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("${fmt(entries.sumOf { it.calories })} kcal", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            IconButton(onClick = onAdd) { Icon(Icons.Filled.Add, "Add food to $meal") }
        }
        if (entries.isEmpty()) Muted("Nothing logged yet")
        entries.forEach { e ->
            Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(e.name, fontWeight = FontWeight.Medium)
                    Muted("${e.quantityLabel} · ${fmt(e.grams)} g · P ${fmt(e.protein)} C ${fmt(e.carbs)} F ${fmt(e.fat)}")
                }
                Text("${fmt(e.calories)} kcal", fontWeight = FontWeight.SemiBold)
                IconButton(onClick = { onDelete(e) }) { Icon(Icons.Filled.Delete, "Delete ${e.name}") }
            }
        }
    }
}

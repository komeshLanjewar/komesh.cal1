package com.caltrack.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.caltrack.app.MainViewModel
import com.caltrack.app.data.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddFoodSheet(vm: MainViewModel, meal: String, day: Long, onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val q by vm.query.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    var selected by remember { mutableStateOf<Food?>(null) }
    var creating by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { vm.query.value = "" } }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state) {
        Box(Modifier.fillMaxHeight(0.88f).padding(horizontal = 16.dp).imePadding()) {
            val food = selected
            when {
                food != null -> QuantityStage(food, onBack = { selected = null }) { grams, label ->
                    vm.addLog(day, meal, food, grams, label); onDismiss()
                }
                creating -> CustomFoodStage(onBack = { creating = false }) { f ->
                    vm.addCustomFood(f) { saved -> creating = false; selected = saved }
                }
                else -> Column {
                    Text("Add to $meal", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = q, onValueChange = { vm.query.value = it },
                        leadingIcon = { Icon(Icons.Filled.Search, null) },
                        placeholder = { Text("Search roti, dal, paneer, egg…") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    TextButton(onClick = { creating = true }) { Text("+ Create custom food") }
                    LazyColumn(Modifier.weight(1f)) {
                        if (results.isEmpty()) item { Muted("No match. Try another word or create a custom food.") }
                        items(results, key = { it.id }) { f ->
                            ListItem(
                                headlineContent = { Text(f.name) },
                                supportingContent = {
                                    Text("${fmt(f.calories)} kcal / 100 g" +
                                        if (f.unit != "g") " · 1 ${f.unit} = ${fmt(f.servingGrams)} g" else "")
                                },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                modifier = Modifier.clickable { selected = f }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuantityStage(food: Food, onBack: () -> Unit, onAdd: (Double, String) -> Unit) {
    val hasServing = food.unit != "g"
    val unitLabel = "${food.unit} (${fmt(food.servingGrams)} g)"
    var gramsMode by remember { mutableStateOf(!hasServing) }
    var qty by remember { mutableStateOf(if (hasServing) "1" else "100") }
    val q = qty.toDoubleOrNull()
    val grams = if (q == null) 0.0 else if (gramsMode) q else q * food.servingGrams
    val ok = q != null && grams > 0 && grams <= 5000
    val n = food.nutrition(grams)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text(food.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (hasServing) {
            ChipGroup(listOf("Grams", unitLabel), if (gramsMode) "Grams" else unitLabel) {
                gramsMode = it == "Grams"; qty = if (gramsMode) "100" else "1"
            }
        }
        NumField(
            if (gramsMode) "Quantity (grams)" else "Quantity (${food.unit})", qty, { qty = it },
            Modifier.fillMaxWidth(), if (!ok) "Enter an amount up to 5000 g" else null
        )
        AppCard {
            Text("${fmt(n.cal)} kcal", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary)
            Muted("for ${fmt(grams)} g")
            Spacer(Modifier.height(10.dp))
            LegendRow(ProteinColor, "Protein", "${fmtQ(n.p)} g")
            Spacer(Modifier.height(4.dp))
            LegendRow(CarbColor, "Carbohydrates", "${fmtQ(n.c)} g")
            Spacer(Modifier.height(4.dp))
            LegendRow(FatColor, "Fat", "${fmtQ(n.f)} g")
            Spacer(Modifier.height(4.dp))
            LegendRow(FiberColor, "Fiber", "${fmtQ(n.fib)} g")
        }
        Button(
            onClick = { onAdd(grams, "${fmtQ(q ?: 0.0)} ${if (gramsMode) "g" else food.unit}") },
            enabled = ok, modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Add to diary") }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun CustomFoodStage(onBack: () -> Unit, onSave: (Food) -> Unit) {
    var name by remember { mutableStateOf("") }
    var cal by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    var c by remember { mutableStateOf("") }
    var f by remember { mutableStateOf("") }
    var fib by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("g") }
    var sg by remember { mutableStateOf("100") }
    var tried by remember { mutableStateOf(false) }

    fun num(s: String) = if (s.isBlank()) 0.0 else s.toDoubleOrNull()
    val calV = cal.toDoubleOrNull(); val pV = num(p); val cV = num(c); val fV = num(f); val fibV = num(fib); val sgV = sg.toDoubleOrNull()
    val nameErr = if (name.isBlank()) "Enter a name" else null
    val calErr = if (calV == null || calV !in 0.0..900.0) "0–900 kcal per 100 g" else null
    val pErr = if (pV == null || pV !in 0.0..100.0) "0–100 g" else null
    val cErr = if (cV == null || cV !in 0.0..100.0) "0–100 g" else null
    val fErr = if (fV == null || fV !in 0.0..100.0) "0–100 g" else null
    val fibErr = if (fibV == null || fibV !in 0.0..100.0) "0–100 g" else null
    val sumErr = if (pV != null && cV != null && fV != null && pV + cV + fV > 100.5) "Protein + carbs + fat can't exceed 100 g per 100 g" else null
    val sgErr = if (unit != "g" && (sgV == null || sgV !in 1.0..3000.0)) "Enter grams per $unit" else null
    fun e(s: String?) = if (tried) s else null

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Custom food", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(name, { name = it.take(40) }, label = { Text("Food name") }, singleLine = true,
            isError = e(nameErr) != null, supportingText = { e(nameErr)?.let { Text(it) } }, modifier = Modifier.fillMaxWidth())
        Muted("Enter nutrition per 100 g")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NumField("Calories", cal, { cal = it }, Modifier.weight(1f), e(calErr))
            NumField("Protein g", p, { p = it }, Modifier.weight(1f), e(pErr))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NumField("Carbs g", c, { c = it }, Modifier.weight(1f), e(cErr))
            NumField("Fat g", f, { f = it }, Modifier.weight(1f), e(fErr))
        }
        NumField("Fiber g", fib, { fib = it }, Modifier.fillMaxWidth(), e(fibErr))
        if (e(sumErr) != null) Text(sumErr!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        Muted("Serving unit (optional)")
        ChipGroup(listOf("g", "piece", "bowl", "cup", "serving"), unit) { unit = it }
        if (unit != "g") NumField("Grams in 1 $unit", sg, { sg = it }, Modifier.fillMaxWidth(), e(sgErr))
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                tried = true
                if (listOf(nameErr, calErr, pErr, cErr, fErr, fibErr, sumErr, sgErr).all { it == null }) {
                    onSave(Food(name = name.trim(), calories = calV!!, protein = pV!!, carbs = cV!!, fat = fV!!, fiber = fibV!!,
                        unit = unit, servingGrams = if (unit == "g") 100.0 else sgV!!, custom = true))
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Save food") }
        Spacer(Modifier.height(24.dp))
    }
}

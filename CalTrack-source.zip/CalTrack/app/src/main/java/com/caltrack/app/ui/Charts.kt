package com.caltrack.app.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/** 0 -> 1 animation that starts when the chart first appears. */
@Composable
fun rememberEnter(): Float {
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { go = true }
    val v by animateFloatAsState(if (go) 1f else 0f, tween(900), label = "enter")
    return v
}

@Composable
fun CalorieRing(consumed: Float, target: Float, modifier: Modifier = Modifier) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    val main = MaterialTheme.colorScheme.primary
    val over = MaterialTheme.colorScheme.error
    val enter = rememberEnter()
    val frac = if (target > 0f) consumed / target else 0f
    Canvas(modifier) {
        val sw = size.minDimension * 0.11f
        val tl = Offset(sw / 2, sw / 2)
        val sz = Size(size.width - sw, size.height - sw)
        drawArc(color = track, startAngle = 0f, sweepAngle = 360f, useCenter = false, topLeft = tl, size = sz, style = Stroke(sw))
        drawArc(
            color = if (frac > 1f) over else main, startAngle = -90f,
            sweepAngle = 360f * frac.coerceIn(0f, 1f) * enter, useCenter = false,
            topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun MacroDonut(protein: Float, carbs: Float, fat: Float, modifier: Modifier = Modifier) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    val enter = rememberEnter()
    val kp = protein * 4f; val kc = carbs * 4f; val kf = fat * 9f
    val total = kp + kc + kf
    Canvas(modifier) {
        val sw = size.minDimension * 0.2f
        val tl = Offset(sw / 2, sw / 2)
        val sz = Size(size.width - sw, size.height - sw)
        if (total <= 0f) {
            drawArc(color = track, startAngle = 0f, sweepAngle = 360f, useCenter = false, topLeft = tl, size = sz, style = Stroke(sw))
        } else {
            var start = -90f
            listOf(kp to ProteinColor, kc to CarbColor, kf to FatColor).forEach { (v, c) ->
                val sweep = 360f * v / total * enter
                drawArc(color = c, startAngle = start, sweepAngle = (sweep - 2f).coerceAtLeast(0f), useCenter = false, topLeft = tl, size = sz, style = Stroke(sw))
                start += sweep
            }
        }
    }
}

@Composable
fun BarChart(values: List<Float>, labels: List<String>, target: Float, modifier: Modifier = Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    val over = MaterialTheme.colorScheme.error
    val line = MaterialTheme.colorScheme.outline
    val enter = rememberEnter()
    Column(modifier) {
        Canvas(Modifier.fillMaxWidth().height(160.dp)) {
            val max = maxOf(values.maxOrNull() ?: 0f, target, 1f) * 1.15f
            val slot = size.width / values.size
            val bw = slot * 0.55f
            values.forEachIndexed { i, v ->
                val h = size.height * (v / max) * enter
                drawRoundRect(
                    color = if (target > 0 && v > target * 1.05f) over else primary,
                    topLeft = Offset(i * slot + (slot - bw) / 2, size.height - h),
                    size = Size(bw, h), cornerRadius = CornerRadius(10f, 10f)
                )
            }
            if (target > 0) {
                val y = size.height - size.height * (target / max)
                drawLine(line, Offset(0f, y), Offset(size.width, y), strokeWidth = 3f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
            labels.forEach {
                Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun LineChart(values: List<Float>, modifier: Modifier = Modifier, ref: Float? = null, color: Color = MaterialTheme.colorScheme.primary) {
    val grid = MaterialTheme.colorScheme.outline
    val enter = rememberEnter()
    Canvas(modifier.fillMaxWidth().height(150.dp)) {
        if (values.isEmpty()) return@Canvas
        var lo = values.min(); var hi = values.max()
        if (ref != null) { lo = minOf(lo, ref); hi = maxOf(hi, ref) }
        if (hi - lo < 1f) { hi += 1f; lo -= 1f }
        val pad = (hi - lo) * 0.12f
        lo -= pad; hi += pad
        val n = values.size
        fun x(i: Int) = if (n == 1) size.width / 2 else size.width * i / (n - 1)
        fun y(v: Float) = size.height - size.height * (v - lo) / (hi - lo)
        clipRect(right = size.width * enter) {
            val area = Path().apply {
                moveTo(x(0), size.height); lineTo(x(0), y(values[0]))
                for (i in 1 until n) lineTo(x(i), y(values[i]))
                lineTo(x(n - 1), size.height); close()
            }
            drawPath(area, Brush.verticalGradient(listOf(color.copy(alpha = 0.30f), Color.Transparent)))
            val path = Path().apply {
                moveTo(x(0), y(values[0]))
                for (i in 1 until n) lineTo(x(i), y(values[i]))
            }
            drawPath(path, color, style = Stroke(5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            if (n <= 14) values.forEachIndexed { i, v -> drawCircle(color, 7f, Offset(x(i), y(v))) }
        }
        if (ref != null) {
            drawLine(grid, Offset(0f, y(ref)), Offset(size.width, y(ref)), strokeWidth = 3f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
        }
    }
}

package com.caltrack.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ProteinColor = Color(0xFF4C8DFF)
val CarbColor = Color(0xFFFFA53D)
val FatColor = Color(0xFFEF5B7B)
val FiberColor = Color(0xFF3DBE8B)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF16875A), onPrimary = Color.White,
    primaryContainer = Color(0xFFC3F2DA), onPrimaryContainer = Color(0xFF002114),
    secondary = Color(0xFF4F6B5C), tertiary = Color(0xFFFF8A3D),
    background = Color(0xFFF3F9F4), surface = Color(0xFFF3F9F4),
    surfaceVariant = Color(0xFFDCE8DF),
    surfaceContainerLowest = Color.White, surfaceContainerLow = Color.White,
    surfaceContainer = Color(0xFFE9F2EB), surfaceContainerHigh = Color(0xFFE1ECE4)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF6FDBA8), onPrimary = Color(0xFF003824),
    primaryContainer = Color(0xFF00513A), onPrimaryContainer = Color(0xFFC3F2DA),
    secondary = Color(0xFFB4CCBC), tertiary = Color(0xFFFFB37A),
    background = Color(0xFF0E1411), surface = Color(0xFF0E1411),
    surfaceVariant = Color(0xFF2B3830),
    surfaceContainerLowest = Color(0xFF0A0F0C), surfaceContainerLow = Color(0xFF161E19),
    surfaceContainer = Color(0xFF1B241F), surfaceContainerHigh = Color(0xFF242E28)
)

@Composable
fun CalTrackTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
}

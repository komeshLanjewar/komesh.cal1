package com.caltrack.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** Nutrition values are per 100 g. */
@Entity(tableName = "foods", indices = [Index("name")])
data class Food(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val calories: Double, val protein: Double, val carbs: Double, val fat: Double, val fiber: Double,
    val unit: String = "g",
    val servingGrams: Double = 100.0,
    val custom: Boolean = false
)

@Entity(tableName = "logs", indices = [Index("day")])
data class LogEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val day: Long, val meal: String, val name: String, val quantityLabel: String, val grams: Double,
    val calories: Double, val protein: Double, val carbs: Double, val fat: Double, val fiber: Double
)

@Entity(tableName = "profile")
data class Profile(
    @PrimaryKey val id: Int = 1,
    val age: Int = 25, val gender: String = "Male",
    val heightCm: Double = 170.0, val weightKg: Double = 70.0,
    val activity: String = "Moderate", val goal: String = "Maintain Weight",
    val calorieTarget: Int = 2000,
    val darkMode: Int = 0 // 0 system, 1 light, 2 dark
)

@Entity(tableName = "weights")
data class WeightEntry(@PrimaryKey val day: Long, val kg: Double)

@Dao
interface FoodDao {
    @Query("SELECT * FROM foods WHERE name LIKE '%' || :q || '%' ORDER BY custom DESC, name LIMIT 100")
    fun search(q: String): Flow<List<Food>>
    @Insert suspend fun insert(food: Food): Long
    @Insert suspend fun insertAll(foods: List<Food>)
    @Query("SELECT COUNT(*) FROM foods") suspend fun count(): Int
}

@Dao
interface LogDao {
    @Query("SELECT * FROM logs WHERE day = :day ORDER BY id")
    fun forDay(day: Long): Flow<List<LogEntry>>
    @Query("SELECT * FROM logs WHERE day BETWEEN :from AND :to ORDER BY day, id")
    fun range(from: Long, to: Long): Flow<List<LogEntry>>
    @Insert suspend fun insert(e: LogEntry)
    @Delete suspend fun delete(e: LogEntry)
}

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profile WHERE id = 1") fun observe(): Flow<Profile?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(p: Profile)
}

@Dao
interface WeightDao {
    @Query("SELECT * FROM weights ORDER BY day") fun all(): Flow<List<WeightEntry>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(w: WeightEntry)
}

@Database(entities = [Food::class, LogEntry::class, Profile::class, WeightEntry::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun foodDao(): FoodDao
    abstract fun logDao(): LogDao
    abstract fun profileDao(): ProfileDao
    abstract fun weightDao(): WeightDao

    companion object {
        fun build(ctx: android.content.Context): AppDb =
            Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "caltrack.db").build()
    }
}
